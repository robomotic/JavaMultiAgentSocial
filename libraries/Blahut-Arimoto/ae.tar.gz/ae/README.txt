Anonymity Engine.

This is a tool for calculating anonymity, capacity and mutual information from a probability transition matrix or from sampled data. Run the program from the command line by typing:

java -jar ae.tar <sample/matrix file>

See http://www.cs.bham.ac.uk/~tpc/AE for more information.



