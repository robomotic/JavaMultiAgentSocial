This directory contains observations of a Mixminion mix node. Short messages to three different addresses were sent into a node and a packet sniffer was used to monitor the outputs. 

The inputs in the samples file are the order in which the messages entered the mix. The outputs are digests of all packets leaving the node. The file packets.txt contains an example of all packets.  The IP address's of the mix nodes are 85.18.113.12, 82.133.6.118 and 79.23.205.199. 
  
The digests for a single firing of the node take the form:

   A0b37p36A2b37p36A1b37p37

where position of A0, A1 and A2 indicates the order in which the first packets where send to the other mix nodes. "b(n)" indicates the number of kb sent to that address and "p" gives the number of packets. So, the digest above means that node 0 was addressed first and it was sent a total of 37kb in 36 packets. The stream to A2 was opened second and totalled 37kb in 36 packets and A1 came third and received 37kb in 37 packets.

The three files in this directory filter out different amounts of this information. All of them are consistent with zero information leakage, although this says nothing about the anonymity of longer messages or correlation attacks across the network.
 

